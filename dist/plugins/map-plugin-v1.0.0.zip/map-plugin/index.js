import React from "react";

const Map = () => {
  return <div>Map</div>;
};

export default {
  name: "Map Plugin",
  version: "1.0.0",
  component: Map,
};
