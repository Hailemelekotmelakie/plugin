import React from "react";

const WikiPlugin = () => {
  return <div>Wiki Plugin</div>;
};

export default {
  name: "Wiki Plugin",
  version: "1.0.0",
  component: WikiPlugin,
};
